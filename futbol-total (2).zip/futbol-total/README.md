# ⚽ FÚTBOL TOTAL — Guía paso a paso

Qué hay en la carpeta:

| Carpeta / archivo | Para qué sirve |
|---|---|
| `public/` | La app que ve la gente (pantallas, íconos, instalación en Android). |
| `netlify/functions/` | El "backend": 3 funciones que consultan las APIs. **Acá vive la clave, nunca en `public/`.** |
| `netlify/lib/` | Piezas internas: proveedor football-data.org, lista de competiciones, fuentes de noticias y tabla de TV (`tv.json`). |
| `netlify.toml` | Configuración de Netlify (ya está lista, no la toques). |

Cómo funciona: la app pide `/api/matches`, `/api/competition` y `/api/news` → Netlify ejecuta la función → la función usa tu clave secreta para consultar football-data.org → devuelve solo los datos. Nadie ve tu clave.

---
## PASO 1 — Clave de football-data.org (gratis)
1. Entrá a https://www.football-data.org y elegí **Register / Free plan**.
2. Confirmá el email. Te llega (y se ve en tu cuenta) un **API Token**: una cadena larga de letras y números.
3. Guardala en un lugar privado. **No la pegues en el chat ni en ningún archivo del proyecto.**

Plan gratuito (confirmá los detalles actuales en https://www.football-data.org/coverage):
- Límite: **10 consultas por minuto**. La app guarda respuestas por 60 segundos para no gastarlas.
- Incluye un grupo de competiciones: en general Premier League, LaLiga, Bundesliga, Serie A, Ligue 1, Champions League y Mundial.
- **No incluye** (en general) Liga Profesional Argentina, Copa Argentina, MLS ni Saudi Pro League; Libertadores y Europa League suelen ser de pago. En esos casos la app muestra el aviso correspondiente, nunca datos inventados.
- Los resultados en vivo pueden tener demora en el plan gratuito.

## PASO 2 — Subir el proyecto a GitHub (gratis)
Netlify necesita leer el proyecto desde GitHub para activar las funciones.
1. Creá una cuenta en https://github.com.
2. Tocá **New repository**, nombre `futbol-total`, dejalo **Private** (o Public, da igual: no hay claves) y **Create repository**.
3. Descomprimí el ZIP en tu computadora. En el repositorio nuevo elegí **uploading an existing file** y arrastrá **todo el contenido** de la carpeta `futbol-total` (incluidas las carpetas `public` y `netlify`). **Commit changes**.
   - Verificá que en GitHub se vea `netlify.toml` en la raíz y las carpetas `public` y `netlify`.

## PASO 3 — Publicar en Netlify (gratis)
1. Creá una cuenta en https://www.netlify.com (podés entrar con tu cuenta de GitHub).
2. **Add new site → Import an existing project → GitHub** y elegí `futbol-total`.
3. No cambies nada (Netlify lee `netlify.toml`) y tocá **Deploy**. Tarda 1–2 minutos.
4. Te da una dirección tipo `https://algo.netlify.app`. En **Site configuration → Change site name** podés elegir una más linda.

## PASO 4 — Conectar la clave (variable de entorno)
1. En Netlify: **Site configuration → Environment variables → Add a variable**.
2. **Key:** `FOOTBALL_DATA_KEY`  **Value:** tu token. Marcá la opción de valor secreto si aparece. Guardá.
3. Andá a **Deploys → Trigger deploy → Deploy site** para que tome la variable.

## PASO 5 — Probar que funciona
- Abrí `https://TU-SITIO.netlify.app/api/matches?date=2026-11-16` (cambiá la fecha por una de hoy). Si ves un texto JSON con `"items"`, funciona.
- Si `message` dice "Falta configurar la variable…", repetí el paso 4. Si dice "límite de consultas", esperá un minuto.
- Después abrí la app: **Partidos**, **Torneos** (tabla de Premier League, LaLiga, etc.) y **Noticias**.
- Errores: en Netlify, **Logs → Functions** muestra qué pasó.

## PASO 6 — Instalar en Android
1. Abrí tu dirección en **Chrome** del celular.
2. Menú ⋮ → **Instalar aplicación** (o "Agregar a la pantalla principal").
3. Aparece el ícono "Fútbol Total" y se abre a pantalla completa.

## PASO 7 — Compartirla
Mandá el link `https://TU-SITIO.netlify.app` por WhatsApp. Cada persona elige sus equipos; se guardan en su propio celular.

---
## "Dónde verlo" (TV y streaming)
Ninguna API gratuita da canales confirmados para Argentina, así que la app **no los inventa**: muestra "Transmisión no confirmada". Cuando verifiques una transmisión en fuentes oficiales (el canal, la plataforma o la liga), cargala en `netlify/lib/tv.json`:
```json
{
  "byMatch": { "fd123456": [ { "channel": "Nombre del canal", "time": "16:00", "url": "https://enlace-oficial" } ] },
  "byCompetition": {}
}
```
El id (`fd123456`) se ve en `/api/matches?date=...`. Para editar: en GitHub abrí el archivo → lápiz → **Commit**; Netlify republica solo.

## Noticias
Las fuentes están en `netlify/lib/feeds.js`. Vienen 4 medios (BBC Sport, The Guardian, ESPN, Sky Sports), **en inglés**. Las categorías por país/liga filtran por palabras clave. No las probé contra los servidores reales: si una URL falla, simplemente se omite. Para sumar medios en español, buscá en su sitio el enlace RSS, verificá que abra un XML en el navegador y agregalo en `FEEDS` y en las categorías.

## Otras APIs de fútbol (estructura ya preparada)
1. Creá `netlify/lib/miapi.js` que exporte `matchesByDate(date)` y `competition(code, view)`, devolviendo `{ items, message }` con el mismo formato que `footballdata.js`.
2. Registrala en `netlify/lib/providers.js`.
3. En `netlify/lib/competitions.js` cambiá `null` por `{ p: 'miapi', code: '...' }` en las competiciones que cubra (ej. Liga Profesional Argentina).
4. Guardá su clave como otra variable de entorno en Netlify (paso 4).
Candidatas gratuitas con límites: **API-Football** (api-sports.io, plan gratis con cupo diario) y **TheSportsDB**. Revisá en cada sitio qué ligas cubre antes de elegir.

## Notificaciones
El botón del Perfil pide el permiso del dispositivo. Enviar avisos con la app cerrada requiere un servicio de *push* (por ejemplo Firebase Cloud Messaging) y una función programada: es una etapa posterior.

## Probar en tu PC (opcional)
Instalá Node.js y `npm i -g netlify-cli`, copiá `.env.example` como `.env` con tu clave y ejecutá `netlify dev`. El archivo `.env` está excluido de GitHub por `.gitignore`.
