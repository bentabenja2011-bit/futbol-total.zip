// GET /api/news?cat=Último momento
const send = require('../lib/http');
const { FEEDS, CATS } = require('../lib/feeds');
const { readFeed } = require('../lib/rss');

exports.handler = async (ev) => {
  const cat = CATS[(ev.queryStringParameters || {}).cat];
  if (!cat) return send({ items: [], message: 'Categoría desconocida.' }, 400);
  if (!cat.feeds.length) return send({ items: [], message: 'Todavía no hay fuentes configuradas para esta categoría.' });
  const rs = await Promise.allSettled(cat.feeds.map(k => readFeed(FEEDS[k])));
  let items = rs.filter(r => r.status === 'fulfilled').flatMap(r => r.value);
  if (cat.keywords) items = items.filter(n => { const t = (n.title + ' ' + n.summary).toLowerCase(); return cat.keywords.some(k => t.includes(k)); });
  const seen = new Set();
  items = items.filter(n => !seen.has(n.url) && seen.add(n.url)).sort((a, b) => (a.date < b.date ? 1 : -1)).slice(0, 30);
  const msg = items.length ? '' : (rs.every(r => r.status === 'rejected') ? 'No se pudieron leer las fuentes de noticias.' : 'No hay noticias recientes para esta categoría.');
  return send({ items, message: msg });
};
