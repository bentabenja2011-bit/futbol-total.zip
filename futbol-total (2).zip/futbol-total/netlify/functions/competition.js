// GET /api/competition?name=Premier League&view=tabla|partidos|jornadas
const send = require('../lib/http');
const providers = require('../lib/providers');
const comps = require('../lib/competitions');

exports.handler = async (ev) => {
  const q = ev.queryStringParameters || {};
  const cfg = comps[q.name];
  const view = ['tabla', 'partidos', 'jornadas'].includes(q.view) ? q.view : 'tabla';
  if (cfg === undefined) return send({ items: [], message: 'Competición desconocida.' }, 400);
  if (!cfg || !providers[cfg.p]) return send({ items: [], message: 'Esta competición todavía no tiene una fuente de datos conectada (ver README, sección "Otras APIs").' });
  try { return send(await providers[cfg.p].competition(cfg.code, view)); }
  catch (e) { return send({ items: [], message: 'Error al consultar los datos.' }); }
};
