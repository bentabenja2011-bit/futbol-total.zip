// GET /api/matches?date=YYYY-MM-DD  (fecha según el calendario de Argentina)
const send = require('../lib/http');
const providers = require('../lib/providers');
const tv = require('../lib/tv.json');

exports.handler = async (ev) => {
  const date = (ev.queryStringParameters || {}).date || '';
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return send({ items: [], message: 'Fecha inválida.' }, 400);
  const res = await Promise.all(Object.values(providers).map(p => p.matchesByDate(date).catch(() => ({ items: [], message: 'Error al consultar un proveedor.' }))));
  const items = res.flatMap(r => r.items).sort((a, b) => (a.utc < b.utc ? -1 : 1));
  // "Dónde verlo": solo lo que cargaste a mano en tv.json. Si no hay dato, la app muestra "Transmisión no confirmada".
  items.forEach(m => { m.tv = (tv.byMatch || {})[m.id] || (tv.byCompetition || {})[m.code] || []; });
  return send({ items, message: items.length ? '' : (res.map(r => r.message).find(Boolean) || '') });
};
